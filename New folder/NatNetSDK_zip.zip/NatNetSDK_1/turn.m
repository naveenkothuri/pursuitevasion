initialise_optitrack();
[pitch,roll]=getdata();
%get_angle();


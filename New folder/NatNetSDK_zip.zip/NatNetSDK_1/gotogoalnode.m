function gotogoalnode(nodes)
node(1) = TODO
for i=2:len(nodes)
    move_final(nodes(i))
end
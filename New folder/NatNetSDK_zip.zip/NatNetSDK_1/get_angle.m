function angle =  get_angle((x1,y1),(x2,y2))
angle = atan((y2-y1),(x2-x1));

end
Hello, 

This s-function is a slightly modified version from "Stefano" that I found on the NaturalPoint's Forum.
(Link : https://forums.naturalpoint.com/viewtopic.php?f=56&t=7566&start=20 last post of the page)
This version is also inspired from the samples you can find in the NatNet files.
Since I didn't need the angles and to improve the speed of this code I've commented this part.
If you're interested in the angles, you only need to change "block.OutputPort(1).Dimensions" as  you wish and to uncomment the last part of the code.

Regards



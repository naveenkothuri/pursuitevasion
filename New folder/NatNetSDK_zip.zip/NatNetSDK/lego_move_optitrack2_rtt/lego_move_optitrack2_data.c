/*
 * File: lego_move_optitrack2_data.c
 *
 * Code generated for Simulink model 'lego_move_optitrack2'.
 *
 * Model version                  : 1.9
 * Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
 * TLC version                    : 8.8 (Jan 20 2015)
 * C/C++ source code generated on : Mon Feb 13 11:44:54 2017
 *
 * Target selection: realtime.tlc
 * Embedded hardware selection: ARM Compatible->ARM 9
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "lego_move_optitrack2.h"
#include "lego_move_optitrack2_private.h"

/* Block parameters (auto storage) */
P_lego_move_optitrack2_T lego_move_optitrack2_P = {
  -50.0,                               /* Expression: -50
                                        * Referenced by: '<Root>/Constant'
                                        */
  -20.0                                /* Expression: -20
                                        * Referenced by: '<Root>/Constant1'
                                        */
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */

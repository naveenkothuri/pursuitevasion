function TraceInfoFlag() {
    this.traceFlag = new Array();
    this.traceFlag["lego_move_optitrack2.c:43c45"]=1;
}
top.TraceInfoFlag.instance = new TraceInfoFlag();
function TraceInfoLineFlag() {
    this.lineTraceFlag = new Array();
    this.lineTraceFlag["lego_move_optitrack2.c:36"]=1;
    this.lineTraceFlag["lego_move_optitrack2.c:39"]=1;
    this.lineTraceFlag["lego_move_optitrack2.c:42"]=1;
    this.lineTraceFlag["lego_move_optitrack2.c:43"]=1;
    this.lineTraceFlag["lego_move_optitrack2.c:44"]=1;
    this.lineTraceFlag["lego_move_optitrack2.c:129"]=1;
    this.lineTraceFlag["lego_move_optitrack2.c:132"]=1;
    this.lineTraceFlag["lego_move_optitrack2.c:139"]=1;
    this.lineTraceFlag["lego_move_optitrack2.c:142"]=1;
}
top.TraceInfoLineFlag.instance = new TraceInfoLineFlag();
